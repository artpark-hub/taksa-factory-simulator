void PLCSIMTEST_init__(PLCSIMTEST *data__, BOOL retain) {
  __INIT_VAR(data__->MACHINE_STATUS,2,retain)
  __INIT_VAR(data__->PART_PRESENT,__BOOL_LITERAL(FALSE),retain)
  __INIT_VAR(data__->CYCLE_TIME_S,0.0,retain)
  __INIT_VAR(data__->DOOR_OPEN,__BOOL_LITERAL(TRUE),retain)
  __INIT_VAR(data__->SCAN_COUNT,0,retain)
  __INIT_VAR(data__->STATE_SEC,0,retain)
  __INIT_VAR(data__->SIM_STATE,0,retain)
  __INIT_VAR(data__->STARTUP_LIMIT,6,retain)
  __INIT_VAR(data__->RUN_LIMIT,130,retain)
  __INIT_VAR(data__->STOP_LIMIT,8,retain)
  __INIT_VAR(data__->RUN_CYCLE_CONST,7.0,retain)
  __INIT_VAR(data__->STOP_CYCLE_CONST,7.0,retain)
  __INIT_VAR(data__->IDEAL_CYCLE_CONST,6.5,retain)
  __INIT_VAR(data__->REJECT_EVERY_N_PARTS,65,retain)
  __INIT_VAR(data__->PLANNED_TIME_S,0,retain)
  __INIT_VAR(data__->RUNTIME_TIME_S,0,retain)
  __INIT_VAR(data__->DOWNTIME_TIME_S,0,retain)
  __INIT_VAR(data__->PART_TIMER_S,0.0,retain)
  __INIT_VAR(data__->TOTAL_COUNT,0,retain)
  __INIT_VAR(data__->GOOD_COUNT,0,retain)
  __INIT_VAR(data__->REJECT_COUNT,0,retain)
  __INIT_VAR(data__->REJECT_COUNTER,0,retain)
  __INIT_VAR(data__->AVAILABILITY_PCT,0.0,retain)
  __INIT_VAR(data__->PERFORMANCE_PCT,0.0,retain)
  __INIT_VAR(data__->QUALITY_PCT,0.0,retain)
  __INIT_VAR(data__->OEE_PCT,0.0,retain)
}

// Code part
void PLCSIMTEST_body__(PLCSIMTEST *data__) {
  // Initialise TEMP variables

  __SET_VAR(data__->,SCAN_COUNT,,(__GET_VAR(data__->SCAN_COUNT,) + 1));
  if ((__GET_VAR(data__->SCAN_COUNT,) >= 50)) {
    __SET_VAR(data__->,SCAN_COUNT,,0);
    __SET_VAR(data__->,STATE_SEC,,(__GET_VAR(data__->STATE_SEC,) + 1));
    __SET_VAR(data__->,PLANNED_TIME_S,,(__GET_VAR(data__->PLANNED_TIME_S,) + 1));
    {
      USINT __case_expression = __GET_VAR(data__->SIM_STATE,);
      if ((__case_expression == 0)) {
        __SET_VAR(data__->,DOWNTIME_TIME_S,,(__GET_VAR(data__->DOWNTIME_TIME_S,) + 1));
        if ((__GET_VAR(data__->STATE_SEC,) >= __GET_VAR(data__->STARTUP_LIMIT,))) {
          __SET_VAR(data__->,SIM_STATE,,1);
          __SET_VAR(data__->,STATE_SEC,,0);
          __SET_VAR(data__->,PART_TIMER_S,,0.0);
        };
      }
      else if ((__case_expression == 1)) {
        __SET_VAR(data__->,RUNTIME_TIME_S,,(__GET_VAR(data__->RUNTIME_TIME_S,) + 1));
        __SET_VAR(data__->,PART_TIMER_S,,(__GET_VAR(data__->PART_TIMER_S,) + 1.0));
        if ((__GET_VAR(data__->PART_TIMER_S,) >= __GET_VAR(data__->RUN_CYCLE_CONST,))) {
          __SET_VAR(data__->,PART_TIMER_S,,(__GET_VAR(data__->PART_TIMER_S,) - __GET_VAR(data__->RUN_CYCLE_CONST,)));
          __SET_VAR(data__->,TOTAL_COUNT,,(__GET_VAR(data__->TOTAL_COUNT,) + 1));
          __SET_VAR(data__->,REJECT_COUNTER,,(__GET_VAR(data__->REJECT_COUNTER,) + 1));
          if ((__GET_VAR(data__->REJECT_EVERY_N_PARTS,) > 0)) {
            if ((__GET_VAR(data__->REJECT_COUNTER,) >= __GET_VAR(data__->REJECT_EVERY_N_PARTS,))) {
              __SET_VAR(data__->,REJECT_COUNT,,(__GET_VAR(data__->REJECT_COUNT,) + 1));
              __SET_VAR(data__->,REJECT_COUNTER,,0);
            } else {
              __SET_VAR(data__->,GOOD_COUNT,,(__GET_VAR(data__->GOOD_COUNT,) + 1));
            };
          } else {
            __SET_VAR(data__->,GOOD_COUNT,,(__GET_VAR(data__->GOOD_COUNT,) + 1));
          };
        };
        if ((__GET_VAR(data__->STATE_SEC,) >= __GET_VAR(data__->RUN_LIMIT,))) {
          __SET_VAR(data__->,SIM_STATE,,2);
          __SET_VAR(data__->,STATE_SEC,,0);
        };
      }
      else if ((__case_expression == 2)) {
        __SET_VAR(data__->,DOWNTIME_TIME_S,,(__GET_VAR(data__->DOWNTIME_TIME_S,) + 1));
        if ((__GET_VAR(data__->STATE_SEC,) >= __GET_VAR(data__->STOP_LIMIT,))) {
          __SET_VAR(data__->,SIM_STATE,,0);
          __SET_VAR(data__->,STATE_SEC,,0);
        };
      }
    };
  };
  {
    USINT __case_expression = __GET_VAR(data__->SIM_STATE,);
    if ((__case_expression == 0)) {
      __SET_VAR(data__->,MACHINE_STATUS,,2);
      __SET_VAR(data__->,PART_PRESENT,,__BOOL_LITERAL(FALSE));
      __SET_VAR(data__->,CYCLE_TIME_S,,0.0);
      __SET_VAR(data__->,DOOR_OPEN,,__BOOL_LITERAL(TRUE));
    }
    else if ((__case_expression == 1)) {
      __SET_VAR(data__->,MACHINE_STATUS,,1);
      __SET_VAR(data__->,PART_PRESENT,,__BOOL_LITERAL(TRUE));
      __SET_VAR(data__->,CYCLE_TIME_S,,__GET_VAR(data__->PART_TIMER_S,));
      __SET_VAR(data__->,DOOR_OPEN,,__BOOL_LITERAL(FALSE));
    }
    else if ((__case_expression == 2)) {
      __SET_VAR(data__->,MACHINE_STATUS,,3);
      __SET_VAR(data__->,PART_PRESENT,,__BOOL_LITERAL(FALSE));
      __SET_VAR(data__->,CYCLE_TIME_S,,__GET_VAR(data__->STOP_CYCLE_CONST,));
      __SET_VAR(data__->,DOOR_OPEN,,__BOOL_LITERAL(TRUE));
    }
  };
  if ((__GET_VAR(data__->PLANNED_TIME_S,) > 0)) {
    __SET_VAR(data__->,AVAILABILITY_PCT,,((DINT_TO_REAL(
      (BOOL)__BOOL_LITERAL(TRUE),
      NULL,
      (DINT)__GET_VAR(data__->RUNTIME_TIME_S,)) / DINT_TO_REAL(
      (BOOL)__BOOL_LITERAL(TRUE),
      NULL,
      (DINT)__GET_VAR(data__->PLANNED_TIME_S,))) * 100.0));
  } else {
    __SET_VAR(data__->,AVAILABILITY_PCT,,0.0);
  };
  if ((__GET_VAR(data__->RUNTIME_TIME_S,) > 0)) {
    __SET_VAR(data__->,PERFORMANCE_PCT,,(((DINT_TO_REAL(
      (BOOL)__BOOL_LITERAL(TRUE),
      NULL,
      (DINT)__GET_VAR(data__->TOTAL_COUNT,)) * __GET_VAR(data__->IDEAL_CYCLE_CONST,)) / DINT_TO_REAL(
      (BOOL)__BOOL_LITERAL(TRUE),
      NULL,
      (DINT)__GET_VAR(data__->RUNTIME_TIME_S,))) * 100.0));
    if ((__GET_VAR(data__->PERFORMANCE_PCT,) > 100.0)) {
      __SET_VAR(data__->,PERFORMANCE_PCT,,100.0);
    };
  } else {
    __SET_VAR(data__->,PERFORMANCE_PCT,,0.0);
  };
  if ((__GET_VAR(data__->TOTAL_COUNT,) > 0)) {
    __SET_VAR(data__->,QUALITY_PCT,,((DINT_TO_REAL(
      (BOOL)__BOOL_LITERAL(TRUE),
      NULL,
      (DINT)__GET_VAR(data__->GOOD_COUNT,)) / DINT_TO_REAL(
      (BOOL)__BOOL_LITERAL(TRUE),
      NULL,
      (DINT)__GET_VAR(data__->TOTAL_COUNT,))) * 100.0));
  } else {
    __SET_VAR(data__->,QUALITY_PCT,,0.0);
  };
  __SET_VAR(data__->,OEE_PCT,,(((__GET_VAR(data__->AVAILABILITY_PCT,) * __GET_VAR(data__->PERFORMANCE_PCT,)) * __GET_VAR(data__->QUALITY_PCT,)) / 10000.0));

  goto __end;

__end:
  return;
} // PLCSIMTEST_body__() 





void MAIN_init__(MAIN *data__, BOOL retain) {
  __INIT_VAR(data__->MACHINE_STATUS,1,retain)
  __INIT_VAR(data__->PART_PRESENT,__BOOL_LITERAL(FALSE),retain)
  __INIT_VAR(data__->CYCLE_START,__BOOL_LITERAL(FALSE),retain)
  __INIT_VAR(data__->CYCLE_STOP,__BOOL_LITERAL(FALSE),retain)
  __INIT_VAR(data__->CYCLE_TIME_S,0.0,retain)
  __INIT_VAR(data__->LOADING_TIME_MS,0,retain)
  __INIT_VAR(data__->UNLOADING_TIME_MS,0,retain)
  __INIT_VAR(data__->DOOR_OPEN,__BOOL_LITERAL(FALSE),retain)
  __INIT_VAR(data__->MACHINE_ERROR_01,__STRING_LITERAL(0,""),retain)
  __INIT_VAR(data__->MACHINE_ERROR_6,__STRING_LITERAL(0,""),retain)
  __INIT_VAR(data__->MACHINE_ERROR_2,__STRING_LITERAL(0,""),retain)
  __INIT_VAR(data__->MACHINE_ERROR_3,__STRING_LITERAL(0,""),retain)
  __INIT_VAR(data__->MACHINE_ERROR_4,__STRING_LITERAL(0,""),retain)
  __INIT_VAR(data__->MACHINE_ERROR_5,__STRING_LITERAL(0,""),retain)
  __INIT_VAR(data__->CURRENT_ERROR_CODE,__STRING_LITERAL(0,""),retain)
  __INIT_VAR(data__->ENERGY_CONSUMPTION_KW,0.0,retain)
  __INIT_VAR(data__->MACHINE_DOWNTIME_S,0,retain)
  __INIT_VAR(data__->MACHINE_POWER_ON,__BOOL_LITERAL(TRUE),retain)
  __INIT_VAR(data__->VIBRATION_RMS_VELOCITY_MM_S,0.0,retain)
  __INIT_VAR(data__->BEARING_TEMP_C,25.0,retain)
  __INIT_VAR(data__->COOLANT_TEMP_C,25.0,retain)
  __INIT_VAR(data__->SPINDLE_SPEED_RPM,0.0,retain)
  __INIT_VAR(data__->SPINDLE_LOAD_PCT,0.0,retain)
  __INIT_VAR(data__->CUTTING_FORCE_N,0.0,retain)
  __INIT_VAR(data__->TOOL_CHANGEOVER,__BOOL_LITERAL(FALSE),retain)
  __INIT_VAR(data__->PRODUCT_ID,__STRING_LITERAL(0,""),retain)
  __INIT_VAR(data__->SPARE_1,0.0,retain)
  __INIT_VAR(data__->SPARE_2,0.0,retain)
  __INIT_VAR(data__->SPARE_3,0.0,retain)
  __INIT_VAR(data__->SPARE_4,0.0,retain)
  __INIT_VAR(data__->SPARE_5,0.0,retain)
  __INIT_VAR(data__->SPARE_6,0.0,retain)
  __INIT_VAR(data__->SPARE_7,0.0,retain)
  __INIT_VAR(data__->SPARE_8,0.0,retain)
  __INIT_VAR(data__->_TMP_AND8351691_OUT,__BOOL_LITERAL(FALSE),retain)
}

// Code part
void MAIN_body__(MAIN *data__) {
  // Initialise TEMP variables

  __SET_VAR(data__->,_TMP_AND8351691_OUT,,AND__BOOL__BOOL(
    (BOOL)__BOOL_LITERAL(TRUE),
    NULL,
    (UINT)2,
    (BOOL)__GET_VAR(data__->MACHINE_POWER_ON,),
    (BOOL)__GET_VAR(data__->MACHINE_POWER_ON,)));
  __SET_VAR(data__->,TOOL_CHANGEOVER,,__GET_VAR(data__->_TMP_AND8351691_OUT,));

  goto __end;

__end:
  return;
} // MAIN_body__() 





