/*
 * This file is part of OpenPLC Runtime
 *
 * Copyright (C) 2023 Autonomy, GP Orcullo
 * Based on the work by GP Orcullo on Beremiz for uC
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include <stdbool.h>

// Include defines.h first for Arduino builds to set USE_*_BLOCKS macros
// before iec_std_FB.h processes its conditional includes
#ifdef ARDUINO
#include "../examples/Baremetal/defines.h"
#endif

#include "iec_types_all.h"
#include "POUS.h"

#define SAME_ENDIANNESS      0
#define REVERSE_ENDIANNESS   1

char plc_program_md5[] = "d5792845f12f0071ec4795f55432fb65";

uint8_t endianness;


extern PLCSIMTEST RES0__INSTANCE0;

static const struct {
    void *ptr;
    __IEC_types_enum type;
} debug_vars[] = {
    {&(RES0__INSTANCE0.MACHINE_STATUS), USINT_ENUM},
    {&(RES0__INSTANCE0.PART_PRESENT), BOOL_ENUM},
    {&(RES0__INSTANCE0.CYCLE_TIME_S), REAL_ENUM},
    {&(RES0__INSTANCE0.DOOR_OPEN), BOOL_ENUM},
    {&(RES0__INSTANCE0.SCAN_COUNT), UINT_ENUM},
    {&(RES0__INSTANCE0.STATE_SEC), UINT_ENUM},
    {&(RES0__INSTANCE0.SIM_STATE), USINT_ENUM},
    {&(RES0__INSTANCE0.STARTUP_LIMIT), UINT_ENUM},
    {&(RES0__INSTANCE0.RUN_LIMIT), UINT_ENUM},
    {&(RES0__INSTANCE0.STOP_LIMIT), UINT_ENUM},
    {&(RES0__INSTANCE0.RUN_CYCLE_CONST), REAL_ENUM},
    {&(RES0__INSTANCE0.STOP_CYCLE_CONST), REAL_ENUM},
    {&(RES0__INSTANCE0.IDEAL_CYCLE_CONST), REAL_ENUM},
    {&(RES0__INSTANCE0.REJECT_EVERY_N_PARTS), UINT_ENUM},
    {&(RES0__INSTANCE0.PLANNED_TIME_S), DINT_ENUM},
    {&(RES0__INSTANCE0.RUNTIME_TIME_S), DINT_ENUM},
    {&(RES0__INSTANCE0.DOWNTIME_TIME_S), DINT_ENUM},
    {&(RES0__INSTANCE0.PART_TIMER_S), REAL_ENUM},
    {&(RES0__INSTANCE0.TOTAL_COUNT), DINT_ENUM},
    {&(RES0__INSTANCE0.GOOD_COUNT), DINT_ENUM},
    {&(RES0__INSTANCE0.REJECT_COUNT), DINT_ENUM},
    {&(RES0__INSTANCE0.REJECT_COUNTER), UINT_ENUM},
    {&(RES0__INSTANCE0.AVAILABILITY_PCT), REAL_ENUM},
    {&(RES0__INSTANCE0.PERFORMANCE_PCT), REAL_ENUM},
    {&(RES0__INSTANCE0.QUALITY_PCT), REAL_ENUM},
    {&(RES0__INSTANCE0.OEE_PCT), REAL_ENUM},
};

#define VAR_COUNT               26

uint16_t get_var_count(void)
{
    return VAR_COUNT;
}

size_t get_var_size(size_t idx)
{
    if (idx >= VAR_COUNT)
    {
        return 0;
    }
    switch (debug_vars[idx].type) {
    case USINT_ENUM:
        return sizeof(USINT);
    case UINT_ENUM:
        return sizeof(UINT);
    case DINT_ENUM:
        return sizeof(DINT);
    case REAL_ENUM:
        return sizeof(REAL);
    case BOOL_ENUM:
        return sizeof(BOOL);
    default:
        return 0;
    }
}

void *get_var_addr(size_t idx)
{
    void *ptr = debug_vars[idx].ptr;

    switch (debug_vars[idx].type) {
    case USINT_ENUM:
        return (void *)&((__IEC_USINT_t *) ptr)->value;
    case UINT_ENUM:
        return (void *)&((__IEC_UINT_t *) ptr)->value;
    case DINT_ENUM:
        return (void *)&((__IEC_DINT_t *) ptr)->value;
    case REAL_ENUM:
        return (void *)&((__IEC_REAL_t *) ptr)->value;
    case BOOL_ENUM:
        return (void *)&((__IEC_BOOL_t *) ptr)->value;
    default:
        return 0;
    }
}

void force_var(size_t idx, bool forced, void *val)
{
    void *ptr = debug_vars[idx].ptr;

    if (forced) {
        size_t var_size = get_var_size(idx);
        switch (debug_vars[idx].type) {
        case USINT_ENUM: {
            memcpy(&((__IEC_USINT_t *) ptr)->value, val, var_size);
            ((__IEC_USINT_t *) ptr)->flags |= __IEC_FORCE_FLAG;
            break;
        }
    
        case UINT_ENUM: {
            memcpy(&((__IEC_UINT_t *) ptr)->value, val, var_size);
            ((__IEC_UINT_t *) ptr)->flags |= __IEC_FORCE_FLAG;
            break;
        }
    
        case DINT_ENUM: {
            memcpy(&((__IEC_DINT_t *) ptr)->value, val, var_size);
            ((__IEC_DINT_t *) ptr)->flags |= __IEC_FORCE_FLAG;
            break;
        }
    
        case REAL_ENUM: {
            memcpy(&((__IEC_REAL_t *) ptr)->value, val, var_size);
            ((__IEC_REAL_t *) ptr)->flags |= __IEC_FORCE_FLAG;
            break;
        }
    
        case BOOL_ENUM: {
            memcpy(&((__IEC_BOOL_t *) ptr)->value, val, var_size);
            ((__IEC_BOOL_t *) ptr)->flags |= __IEC_FORCE_FLAG;
            break;
        }
    
        default:
            break;
        }
    } else {
        switch (debug_vars[idx].type) {
        case USINT_ENUM:
            ((__IEC_USINT_t *) ptr)->flags &= ~__IEC_FORCE_FLAG;
            break;
        case UINT_ENUM:
            ((__IEC_UINT_t *) ptr)->flags &= ~__IEC_FORCE_FLAG;
            break;
        case DINT_ENUM:
            ((__IEC_DINT_t *) ptr)->flags &= ~__IEC_FORCE_FLAG;
            break;
        case REAL_ENUM:
            ((__IEC_REAL_t *) ptr)->flags &= ~__IEC_FORCE_FLAG;
            break;
        case BOOL_ENUM:
            ((__IEC_BOOL_t *) ptr)->flags &= ~__IEC_FORCE_FLAG;
            break;
        default:
            break;
        }
    }
}

void swap_bytes(void *ptr, size_t size)
{
    uint8_t *bytePtr = (uint8_t *)ptr;
    size_t i;
    for (i = 0; i < size / 2; ++i)
    {
        uint8_t temp = bytePtr[i];
        bytePtr[i] = bytePtr[size - 1 - i];
        bytePtr[size - 1 - i] = temp;
    }
}

void trace_reset(void)
{
    for (size_t i=0; i < VAR_COUNT; i++)
    {
        force_var(i, false, 0);
    }
}

void set_trace(size_t idx, bool forced, void *val)
{
    if (idx >= 0 && idx < VAR_COUNT)
    {
        if (endianness == REVERSE_ENDIANNESS)
        {
            // Prevent swapping for STRING type
            if (debug_vars[idx].type == STRING_ENUM)
            {
                // Do nothing
                ;
            }
            else
            {
                swap_bytes(val, get_var_size(idx));
            }
        }

        force_var(idx, forced, val);
    }
}

void set_endianness(uint8_t value)
{
    if (value == SAME_ENDIANNESS || value == REVERSE_ENDIANNESS)
    {
        endianness = value;
    }
}
